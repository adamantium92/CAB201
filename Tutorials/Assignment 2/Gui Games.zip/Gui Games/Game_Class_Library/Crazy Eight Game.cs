﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Game_Class_Library {

    public static class Crazy_Eight_Game {

    }//end class
}
